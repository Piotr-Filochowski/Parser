import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserInterface {


    ArrayList<String> tokens = new ArrayList<>();
    Map<String, String> variables = new LinkedHashMap();
    ReversePolishNotation reversePolishNotation = new ReversePolishNotation(variables);

    void start(){

        String input;
        Scanner scanner = new Scanner(System.in);
        String operation;
        String variableName;


        while(true){
            tokens.clear();
            input = scanner.nextLine();
            generateTokens(input);
            operation = checkOperation(input);
            if(operation.equals("set")){
                variableName = removeVariableNameAndComa();
                  variables.put(variableName, calculate());
            } else if(operation.equals("print")){ ;
                System.out.println(calculate());
            } else{
                riseError();
            }
        }
    }

    private  void generateTokens(String input){
        String temp;
        String tokensPattern = "[a-zA-Z]+|,|[0-9]+|\\+|-|\\*|\\(|\\)";
        Pattern regex = Pattern.compile(tokensPattern);
        Matcher matcher = regex.matcher(input);

        while (matcher.find()) {
            temp = matcher.group(0);
            tokens.add(temp);
        }
    }

    private String checkOperation(String input) {
        String temp =  tokens.remove(0);
        if(temp.equals("print")){
            return temp;
        } else if(temp.equals("set")){
            return temp;
        } else {
            return "ERROR";
        }
    }

    private String removeVariableNameAndComa() {
        String variableName;
        String coma;
        variableName = tokens.remove(0);
        coma = tokens.remove(0);
        if(!coma.equals(",")){
            riseError();
        }
        return variableName;
    }

    private void riseError() {
        System.out.println("ERROR");
    }


    String calculate(){
        Queue<String> queueTokens = new LinkedList<>(tokens);
        reversePolishNotation.setTokens(queueTokens);
        reversePolishNotation.convert();
        return reversePolishNotation.calculate();
    }

}
