class BinaryTree
{
    Node root;

    // Constructors 
    BinaryTree(Node root)
    {
        this.root = root;
    }

}